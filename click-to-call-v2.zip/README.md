# Click-to-Call v2

Render 배포용 Node.js 서버입니다.
- Express 기반
- Dockerfile 포함
- .env로 환경 설정
